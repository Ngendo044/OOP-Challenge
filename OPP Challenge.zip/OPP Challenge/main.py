from pet import Pet

# Create your digital pet
my_pet = Pet("Buddy")

# Interact with your pet
my_pet.get_status()
my_pet.eat()
my_pet.sleep()
my_pet.play()
my_pet.get_status()

# Bonus methods
my_pet.train("roll over")
my_pet.train("fetch")
my_pet.show_tricks()
